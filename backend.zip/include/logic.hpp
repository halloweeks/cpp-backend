#ifndef SERVER_LOGIC_HPP
#define SERVER_LOGIC_HPP

#include <iostream> /* This header file include for input or output */
#include <mariadb/mysql.h> /* We use this header for MySQL */

/* Server logic and MySQL class */
class mariadb {
   private:
   MYSQL *connection;
   MYSQL_RES *results;
   MYSQL_ROW row;
   std::string ResponseMessage;
   
   public:
   int mysql_open();
   std::string Response();
   int LoginWithPlayGames(std::string);
   int RegisterWithPlayGames(std::string, std::string);
};

/* We are create this function for
 open connection without repeat 
this code every function */
int mariadb::mysql_open(){
   connection = mysql_init(NULL);
   if (!connection) {
  	// ResponseMessage = "{\"return\": false, \"message\": \"MySQL initialisation failed\"}";
      // std::cout << "[WARNING] MySQL Initialization" << std::endl;
      return false;
   }
   
   connection = mysql_real_connect(connection, "localhost", "root", "1234", NULL, 0, NULL, 0);
   if (!connection) {
      // ResponseMessage = "{\"return\": false, \"message\": \"MySQL failed to connect\"}";
      // std::cout << "[WARNING] CAN'T CONNECT MySQL SERVER" << std::endl;
      return false;
   }
  return true;
}

std::string mariadb::Response() {
   return ResponseMessage;
}

// User Email and Password Login System
int mariadb::LoginWithPlayGames(std::string email) {
	int status = 1, TotalAccount = 0;
	// This is MySQL select query string. and that query not protected by sql injection
	std::string sql = "SELECT * FROM server.users WHERE email='"+email+"'";
	// if the MySQL connection is not open to return 0 with login failed
	if(!mariadb::mysql_open()) {
		// MySQL connection is not open to exit
		std::cout << "[WARNING] WE CAN'T OPEN MYSQL CONNECTION" << std::endl;
		ResponseMessage = "{\"return\": false, \"message\": \"Can't open MySQL connection\"}";
		return 0;
	} else {
		// if MySQL failed
		if(mysql_query(connection, sql.c_str())) {
			std::cout << "[WARNING] LOGIN QUERY FAILED: " << mysql_error(connection) << std::endl;
			ResponseMessage = "{\"return\": false, \"message\": \"Query failed\", \"code\": \"465\"}";
			status = 0;
		} else {
			results = mysql_store_result(connection);
			// select query number of rows found
			TotalAccount = mysql_num_rows(results);
			if (TotalAccount == 1) {
				std::cout << "[INFO] ACCOUNT FOUND" << std::endl;
				ResponseMessage = "{\"return\": true, \"message\": \"Login success!\", \"code\": \"465\"}";
			} else if (TotalAccount > 1) { // if user account found multiple
				std::cout << "[INFO] ACCOUNT FOUND BUT SAME EMAIL USE " << TotalAccount << " ACCOUNTS" << std::endl;
				ResponseMessage = "{\"return\": false, \"callback\": \"register\", \"message\": \"Your account technical problem please contact support\"}";
				status = 0;
			} else {
				// user account not found our database
				ResponseMessage = "{\"return\": false, \"callback\": \"register\", \"message\": \"This email doesn't exist in our database\"}";
				status = 0;
				std::cout << "[INFO] ACCOUNT NOT FOUND" << std::endl;
			}
		}
		// Closing the open MySQL connection
		mysql_close(connection);
	}
	// return process status
	return status;
}

/* User create account function */
int mariadb::RegisterWithPlayGames(std::string username, std::string email) {
   // status default true   
	int status = 1;
	// MySQL select query string
	std::string sql = "SELECT * FROM server.users WHERE username='"+username+"' OR email='"+email+"'";
	// MySQL insert query string
	std::string sqli = "INSERT INTO server.users (`username`, `email`, `password`) VALUES ('"+username+"', '"+email+"', '1')";
	// Open the MySQL connection
	if(!mariadb::mysql_open()) {
		// If the MySQL connection is not open
		std::cout << "[WARNING] WE CAN'T OPEN MYSQL CONNECTION" << std::endl;
		ResponseMessage = "{\"return\": false, \"message\": \"Can't open MySQL connection\"}";
		return 0;
	} else {
		if (mysql_query(connection, sql.c_str())) {
			std::cout << "[WARNING] REGISTRATION QUERY FAILED: " << mysql_error(connection) << std::endl;
			ResponseMessage = "{\"return\": false, \"message\": \"Registration query failed\"}";
			status = 0;
		} else {
			results = mysql_store_result(connection);
			if (mysql_num_rows(results) > 0) {
				row=mysql_fetch_row(results);
				if (!username.compare(row[1])) {
					ResponseMessage = "{\"return\": false, \"message\": \"Username already taken\"}";
					status = 0;
					std::cout << "[INFO] USERNAME ALREADY TAKEN" << std::endl;
				} else if (!email.compare(row[2])) {
					ResponseMessage = "{\"return\": false, \"message\": \"Email already registered\"}";
					status = 0;
					std::cout << "[INFO] EMAIL ALREADY REGISTERED" << std::endl;
				}
			} else {
				if(mysql_query(connection, sqli.c_str())) {
					std::cout << "[WARNING] REGISTRATION QUERY FAILED: " << mysql_error(connection) << std::endl;
					ResponseMessage = "{\"return\": false, \"message\": \"Registration query failed\"}";
					status = 0;
				} else {
					ResponseMessage = "{\"return\": true, \"message\": \"Account has been created\"}";
				}
			}
			
		}
		// closing the MySQL connection
		mysql_close(connection);
	}
	
	return status;
}

// pointer
mariadb *db = new mariadb;

#endif