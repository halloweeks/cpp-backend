#ifndef SERVER_LOGIC_HPP
#define SERVER_LOGIC_HPP

#include <iostream> /* This header file include for input or output */
#include <mariadb/mysql.h> /* We use this header for MySQL */

/* Server logic and MySQL class */
class mariadb {
   private:
   MYSQL *connection;
   MYSQL_RES *results;
   MYSQL_ROW row;
   std::string ResponseMessage;
   
   public:
   int mysql_open();
   std::string Response();
   int LoginWithEmailPassword(std::string, std::string);
   int RegisterWithEmailPassword(std::string, std::string, std::string);
};

/* We are create this function for
 open connection without repeat 
this code every function */
int mariadb::mysql_open(){
   connection = mysql_init(NULL);
   if (!connection) {
  	ResponseMessage = "{\"return\": false, \"message\": \"Server currently busy\"}";
      std::cout << "[WARNING] MySQL Initialization" << std::endl;
      return false;
   }
   
   connection = mysql_real_connect(connection, "localhost", "root", "1234", NULL, 0, NULL, 0);
   if (!connection) {
      ResponseMessage = "{\"return\": false, \"message\": \"Server currently busy\"}";
      std::cout << "[WARNING] CAN'T CONNECT MySQL SERVER" << std::endl;
      return false;
   }
  return true;
}

std::string mariadb::Response() {
   return ResponseMessage;
}

// User Email and Password Login System
int mariadb::LoginWithEmailPassword(std::string email, std::string password) {
	int status = 1;
	// This is MySQL select query string
	std::string sql = "SELECT * FROM server.users WHERE email='"+email+"'";
	// if the MySQL connection is not open to return 0 with login failed
	if(!mariadb::mysql_open()) {
		// Return 0 means exit here without run any other processing
		return 0;
	} else {
		// if MySQL failed
		if(mysql_query(connection, sql.c_str())) {
			std::cout << "[WARNING] LOGIN QUERY FAILED: " << mysql_error(connection) << std::endl;
			ResponseMessage = "{\"return\": false, \"message\": \"Query failed\", \"code\": \"465\"}";
			status = 0;
		} else {
			results = mysql_store_result(connection);
			if (mysql_num_rows(results) == 1) {
				std::cout << "[INFO] ACCOUNT FOUND" << std::endl;
				while (((row=mysql_fetch_row(results)) !=NULL)) {
					if(!password.compare(row[3])) {
						std::cout << "[INFO] PASSWORD MATCHED" << std::endl;
						ResponseMessage = "{\"return\": true, \"message\": \"Login success!\", \"code\": \"465\"}";
					} else {
						status = 0;
						std::cout << "[INFO] PASSWORD DOESN'T MATCH" << std::endl;
						ResponseMessage = "{\"return\": false, \"message\": \"Password incorrect\"}";
					}
				}
			} else {
				ResponseMessage = "{\"return\": false, \"callback\": \"register\", \"message\": \"This email doesn't exist in our database\"}";
				status = 0;
				std::cout << "[INFO] ACCOUNT NOT FOUND" << std::endl;
			}
		}
		// Closing the open MySQL connection
		mysql_close(connection);
	}
	// return process status
	return status;
}

/* User create account function */
int mariadb::RegisterWithEmailPassword(std::string username, std::string email, std::string password) {
   // status default true   
	int status = 1;
	// MySQL select query string
	std::string sql = "SELECT * FROM server.users WHERE username='"+username+"' OR email='"+email+"'";
	// MySQL insert query string
	std::string sqli = "INSERT INTO server.users (`username`, `email`, `password`) VALUES ('"+username+"', '"+email+"', '"+password+"')";
	// Open the MySQL connection
	if(!mariadb::mysql_open()) {
		// If the MySQL connection is not open
		std::cout << "[WARNING] WE CAN'T OPEN MYSQL CONNECTION" << std::endl;
		ResponseMessage = "{\"return\": false, \"message\": \"Registration query failed\"}";
		status = 0;
	} else {
		if (mysql_query(connection, sql.c_str())) {
			std::cout << "[WARNING] REGISTRATION QUERY FAILED: " << mysql_error(connection) << std::endl;
			ResponseMessage = "{\"return\": false, \"message\": \"Registration query failed\"}";
			status = 0;
		} else {
			results = mysql_store_result(connection);
			if (mysql_num_rows(results) > 0) {
				row=mysql_fetch_row(results);
				if (!username.compare(row[1])) {
					ResponseMessage = "{\"return\": false, \"message\": \"Username already taken\"}";
					status = 0;
					std::cout << "[INFO] USERNAME ALREADY TAKEN" << std::endl;
				} else if (!email.compare(row[2])) {
					ResponseMessage = "{\"return\": false, \"message\": \"Email already registered\"}";
					status = 0;
					std::cout << "[INFO] EMAIL ALREADY REGISTERED" << std::endl;
				}
			} else {
				if(mysql_query(connection, sqli.c_str())) {
					std::cout << "[WARNING] REGISTRATION QUERY FAILED: " << mysql_error(connection) << std::endl;
					ResponseMessage = "{\"return\": false, \"message\": \"Registration query failed\"}";
					status = 0;
				} else {
					ResponseMessage = "{\"return\": true, \"message\": \"Account has been created\"}";
				}
			}
			
		}
		
		mysql_close(connection);
	}
	
	return status;
}

// pointer
mariadb *db = new mariadb;

#endif