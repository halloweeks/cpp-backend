#ifndef SERVER_LOGIC_HPP
#define SERVER_LOGIC_HPP

#include <iostream>
#include <mariadb/mysql.h>
#include "color.hpp"

class mariadb {
	private:
	MYSQL *connection;
	MYSQL_RES *results;
	MYSQL_ROW row;
	std::string ResponseMessage;
	
	public:
	int mysql_open();
	std::string Response();
	
	int LoginWithEmailPassword(std::string, std::string);
	int RegisterWithEmailPassword(std::string, std::string, std::string);
};

int mariadb::mysql_open(){
  connection = mysql_init(NULL);
  if (!connection) {
  	ResponseMessage = "{\"return\": false, \"message\": \"Server currently busy\"}";
      std::cout << color::yellow("[WARNING]") << " MySQL Initialization" << std::endl;
      return false;
  }
	connection = mysql_real_connect(connection, "localhost", "root", "1234", NULL, 0, NULL, 0);
	if (!connection) {
		ResponseMessage = "{\"return\": false, \"message\": \"Server currently busy\"}";
		std::cout << color::yellow("[WARNING]") << " Can't connect MySQL server" << std::endl;
		return false;
	}
	return true;
}

std::string mariadb::Response() {
  return ResponseMessage;
}

// Login Email and Password System
int mariadb::LoginWithEmailPassword(std::string email, std::string password) {
	int state = 1;
	std::string sql = "SELECT * FROM server.users WHERE email='"+email+"'";
	if(!mariadb::mysql_open()) {
		state = 0;
	} else {
		if(mysql_query(connection, sql.c_str())) {
			std::cout << color::yellow("[WARNING]") << " Login query failed: " << mysql_error(connection) << std::endl;
			state = 0;
		}
		results = mysql_store_result(connection);
		if (mysql_num_rows(results) == 1) {
			std::cout << color::green("[SUCCESS]") << " Account found" << std::endl;
			while (((row=mysql_fetch_row(results)) !=NULL)) {
				if(!password.compare(row[3])) {
					std::cout << color::green("[SUCCESS]") << " Password matched" << std::endl;
					ResponseMessage = "{\"return\": true, \"message\": \"Login success!\", \"code\": \"465\"}";
				} else {
					state = 0;
					std::cout << color::red("[FAILED]") << " Password doesn't match" << std::endl;
					ResponseMessage = "{\"return\": false, \"message\": \"Password incorrect\"}";
				}
			}
		} else {
			ResponseMessage = "{\"return\": false, \"callback\": \"register\", \"message\": \"This email doesn't exist in our database\"}";
			state = 0;
			std::cout << color::red("[FAILED]") << " Account not found" << std::endl;
		}
		mysql_close(connection);
	}
	return state;
}


int mariadb::RegisterWithEmailPassword(std::string username, std::string email, std::string password) {
	int state = 1;
	std::string sql = "SELECT * FROM server.users WHERE username='"+username+"' OR email='"+email+"'";
	std::string sqli = "INSERT INTO server.users (`username`, `email`, `password`) VALUES ('"+username+"', '"+email+"', '"+password+"')";
	if(!mariadb::mysql_open()) {
		state = 0;
	} else {
		mysql_query(connection, sql.c_str());
		results = mysql_store_result(connection);
		if (mysql_num_rows(results) > 0) {
			row=mysql_fetch_row(results);
			if (!username.compare(row[1])) {
				ResponseMessage = "{\"return\": false, \"message\": \"Username already taken\"}";
				state = 0;
				std::cout << color::yellow("[WARNING]") << " Username already taken" << std::endl;
			} else if (!email.compare(row[2])) {
				ResponseMessage = "{\"return\": false, \"message\": \"Email already registered\"}";
				state = 0;
				std::cout << color::yellow("[WARNING]") << " Email already registered" << std::endl;
			}
		} else {
			if(mysql_query(connection, sqli.c_str())) {
				std::cout << "Select: " << sql << std::endl << "Insert: " << sqli << std::endl;
				std::cout << color::yellow("[WARNING]") << " Registration query failed: " << mysql_error(connection) << std::endl;
				ResponseMessage = "{\"return\": false, \"message\": \"Registration query failed\"}";
				state = 0;
			} else {
				ResponseMessage = "{\"return\": true, \"message\": \"Account has been created\"}";
			}
		}
		mysql_close(connection);
	}
	return state;
}


#endif