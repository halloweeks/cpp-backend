#ifndef _REQUEST_HANDLER_
#define _REQUEST_HANDLER_

#include <string>
#include <nlohmann/json.hpp>

using json = nlohmann::json;

class RequestHandler {
	private:
	json data;
	
	public:
	bool LoadRequest(std::string);
	std::string Request(const char*);
	bool Isset(std::string);
};

bool RequestHandler::LoadRequest(std::string packet) {
	if (!json::accept(packet)) {
		return false;
	} else {
		data = json::parse(packet);
		return true;
	}
}

std::string RequestHandler::Request(const char* KeyName) {
	for (auto it = data.begin(); it != data.end(); ++it) {
		if (KeyName == it.key()) {
			return it.value();
		}
	}
	return "-1";
}

bool RequestHandler::Isset(std::string packet) {
	if (!packet.compare("-1")) {
		return false;
	}
	return true;
}

RequestHandler *client = new RequestHandler;

#endif