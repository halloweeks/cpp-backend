#ifndef _REQUEST_HANDLER_
#define _REQUEST_HANDLER_

#include <string>
#include <nlohmann/json.hpp>

using json = nlohmann::json;

class RequestHandler {
	private:
	std::string ErrorMessage;
	json data;
	
	public:
	bool LoadRequest(std::string);
	std::string Request(const char*);
	bool Isset(std::string);
	std::string TellErrors();
};

bool RequestHandler::LoadRequest(std::string packet) {
	if (!json::accept(packet)) {
		return false;
	} else {
		data = json::parse(packet);
		return true;
	}
}


std::string RequestHandler::Request(const char* KeyName) {
	for (auto it = data.begin(); it != data.end(); ++it) {
		if (KeyName == it.key()) {
			return it.value();
		}
	}
	return "";
}

bool RequestHandler::Isset(std::string packet) {
	if (!packet.compare("")) {
		return false;
	}
	return true;
}

std::string RequestHandler::TellErrors(){
	return ErrorMessage;
}

RequestHandler *client = new RequestHandler;

#endif