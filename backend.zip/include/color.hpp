#ifndef _COLOR_HPP_
#define _COLOR_HPP_

namespace color {

std::string red(std::string text) {
	return "\033[0;91m" + text + "\033[0m";
}

std::string green(std::string text) {
	return "\033[0;92m" + text + "\033[0m";
}

std::string blue(std::string text) {
	return "\033[0;94m" + text + "\033[0m";
}

std::string yellow(std::string text) {
	return "\033[0;93m" + text + "\033[0m";
}

std::string gray(std::string text) {
	return "\033[1;30m" + text + "\033[0m";
}

std::string cyan(std::string text) {
	return "\033[46m" + text + "\033[0m";
}

}

#endif