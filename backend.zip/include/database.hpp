#ifndef _DATABASE_
#define _DATABASE_

#include <iostream>
#include <mariadb/mysql.h>

class mariadb {
	private:
	MYSQL *connect;
	MYSQL_RES *results;
	MYSQL_ROW row;
	std::string error_msg;
	std::string success_msg;
	
	public:
	int mysqli_open();
	int mysqli_close();
	std::string error_message();
	std::string success_message();
	
	int LoginWithEmailPassword(std::string, std::string);
	int RegisterWithEmailPassword(std::string, std::string, std::string);
};

int mariadb::mysqli_open(){
  connect = mysql_init(NULL);
  if (!connect) {
  	error_msg = "{\"return\": false, \"message\": \"Server currently busy\"}";
    std::cout << "[WARNING] MySQL Initialization" << std::endl;
    return false;
  }
	connect = mysql_real_connect(connect, "localhost", "root", "1234", NULL, 0, NULL, 0);
	if (!connect) {
		error_msg = "{\"return\": false, \"message\": \"Server currently busy\"}";
		std::cout << "[WARNING] Can't connect MySQL server" << std::endl;
		return false;
	}
	return true;
}

int mariadb::mysqli_close(){
	if (connect) {
		mysql_close(connect);
		return true;
	}
	return false;
}

std::string mariadb::error_message() {
  return error_msg;
}

std::string mariadb::success_message(){
	return success_msg;
}

// Login Email and Password System
int mariadb::LoginWithEmailPassword(std::string email, std::string password) {
	int state = 1;
	std::string sql = "SELECT * FROM server.users WHERE email='"+email+"'";
	if(!mariadb::mysqli_open()) {
		state = 0;
	} else {
		if(mysql_query(connect, sql.c_str())) {
			std::cout << "[WARNING] Login query failed: " << mysql_error(connect) << std::endl;
			state = 0;
		}
		results = mysql_store_result(connect);
		if (mysql_num_rows(results) == 1) {
			std::cout << "[NOTE] Account found" << std::endl;
			while (((row=mysql_fetch_row(results)) !=NULL)) {
				if(!password.compare(row[3])) {
					std::cout << "[NOTE] Password matched" << std::endl;
					success_msg = "{\"return\": true, \"message\": \"Login success!\", \"code\": \"465\"}";
				} else {
					state = 0;
					std::cout << "[NOTE] Password doesn't match" << std::endl;
					error_msg = "{\"return\": false, \"message\": \"Password incorrect\"}";
				}
			}
		} else {
			error_msg = "{\"return\": false, \"callback\": \"register\", \"message\": \"This email doesn't exist in our database\"}";
			state = 0;
			std::cout << "[NOTE] Account not found" << std::endl;
		}
		mariadb::mysqli_close();
	}
	return state;
}


int mariadb::RegisterWithEmailPassword(std::string username, std::string email, std::string password) {
	int state = 1;
	std::string sql = "SELECT * FROM server.users WHERE username='"+username+"' OR email='"+email+"'";
	std::string sqli = "INSERT INTO server.users (`username`, `email`, `password`) VALUES ('"+username+"', '"+email+"', '"+password+"')";
	if(!mariadb::mysqli_open()) {
		state = 0;
	} else {
		mysql_query(connect, sql.c_str());
		results = mysql_store_result(connect);
		if (mysql_num_rows(results) > 0) {
			row=mysql_fetch_row(results);
			if (!username.compare(row[1])) {
				error_msg = "{\"return\": false, \"message\": \"Username already taken\"}";
				state = 0;
				std::cout << "[NOTE] Username already taken" << std::endl;
			} else if (!email.compare(row[2])) {
				error_msg = "{\"return\": false, \"message\": \"Email already registered\"}";
				state = 0;
				std::cout << "[NOTE] Email already registered" << std::endl;
			}
		} else {
			if(mysql_query(connect, sqli.c_str())) {
				std::cout << "Select: " << sql << std::endl << "Insert: " << sqli << std::endl;
				std::cout << "[WARNING] Registration query failed: " << mysql_error(connect) << std::endl;
				error_msg = "{\"return\": false, \"message\": \"Registration query failed\"}";
				state = 0;
			} else {
				success_msg = "{\"return\": true, \"message\": \"Account has been created\"}";
			}
		}
		mariadb::mysqli_close();
	}
	return state;
}


#endif