#ifndef BACKEND_PROCESS_HPP
#define BACKEND_PROCESS_HPP

#include <iostream>
#include "logic.hpp"
#include "request_handler.hpp"

#include <iomanip>
#include <time.h>

RequestHandler *client = new RequestHandler;
mariadb *db = new mariadb;

class backend_handler {
	private:
	    clock_t start, end;
	public:
	    std::string ProcessToBackend(std::string);
	    void TimerStart();
	    void TimerStop();
	    void PrintTime();
};

std::string backend_handler::ProcessToBackend(std::string packet) {
	if(!client->LoadRequest(packet)) {
		std::cout << "[WARNING] Invalid json parse" << std::endl;
	} else {
		// client request process
		if (client->Isset(client->Request("login"))) {
			std::cout << color::blue("[REQUEST]") << " Login request" << std::endl;
			if(db->LoginWithEmailPassword(client->Request("email"), client->Request("password"))) {
				std::cout << color::green("[SUCCESS]") << " Login successful" << std::endl;
				return db->Response();
			} else {
                std::cout << color::red("[FAILED]") << " Login failed" << std::endl;
				return db->Response();
			}
		} else if (client->Isset(client->Request("register"))) {
			std::cout << color::blue("[REQUEST]") << " Registration request" << std::endl;
			if (db->RegisterWithEmailPassword(client->Request("username"), client->Request("email"), client->Request("password"))) {
				std::cout << color::green("[SUCCESS]") << " Registration successfull" << std::endl;
				return db->Response();
			} else {
				std::cout << color::red("[FAILED]") << " Registration failed" << std::endl;
				return db->Response();
			}
		} else {
		  std::cout << color::yellow("[WARNING]") << " Unknown Request" << std::endl;
		}
		
	}
	return "{\"return\": true, \"message\": \"Internal server bug\"}"; 
}

void backend_handler::TimerStart(){
	/* Recording the starting clock tick.*/
    start = clock();
}

void backend_handler::TimerStop(){
	// Recording the end clock tick. 
    end = clock(); 
}

void backend_handler::PrintTime(){
	// Calculating total time taken by the program. 
    double time_taken = double(end - start) / double(CLOCKS_PER_SEC);
    std::cout << color::blue("[NOTE]") << " Process completed in " << std::fixed << time_taken << std::setprecision(5) << " sec" << std::endl;
}

#endif