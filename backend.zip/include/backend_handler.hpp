#ifndef BACKEND_PROCESS_HPP
#define BACKEND_PROCESS_HPP

#include <iostream>
#include "logic.hpp"
#include "request_handler.hpp"
#include <iomanip>
#include <time.h>

class backend_handler {
   public:
   std::string ProcessToBackend(std::string); 
   void TimerStart();
   void TimerStop();
   void PrintTime();
};

std::string backend_handler::ProcessToBackend(std::string packet) {
	if(!client->LoadRequest(packet)) {
		std::cout << "[WARNING] INVALID JSON PARSE" << std::endl;
	} else {
		// client request process
		if (client->Isset(client->Request("login"))) {
			std::cout << "[INFO] LOGIN REQUEST" << std::endl;
			if(db->LoginWithEmailPassword(client->Request("email"), client->Request("password"))) {
				std::cout << "[INFO] LOGIN SUCCESSFUL" << std::endl;
				return db->Response();
			} else {
                std::cout << "[INFO] LOGIN FAILED" << std::endl;
				return db->Response();
			}
		} else if (client->Isset(client->Request("register"))) {
			std::cout << "[INFO] REGISTRATION REQUEST" << std::endl;
			if (db->RegisterWithEmailPassword(client->Request("username"), client->Request("email"), client->Request("password"))) {
				std::cout << "[INFO] REGISTRATION SUCCESSFULLY" << std::endl;
				return db->Response();
			} else {
				std::cout << "[INFO] REGISTRATION FAILED" << std::endl;
				return db->Response();
			}
		} else {
		  std::cout << "[WARNING] UNKNOWN REQUEST" << std::endl;
		}
		
	}
	return "{\"return\": true, \"message\": \"Internal server bug\"}"; 
}

backend_handler *callback = new backend_handler;

#endif