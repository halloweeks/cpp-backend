#ifndef _PROCESS_TO_BACKEND
#define _PROCESS_TO_BACKEND

#include <iostream>
#include "database.hpp"
#include "request_handler.hpp"

#include <iomanip>
#include <time.h>

RequestHandler *call = new RequestHandler;
mariadb *db = new mariadb;

class backend_handler {
	private:
	    std::string ResponseData;
	    int IsInvalidRequest = 0;
	    clock_t start, end;
	public:
	    std::string ProcessToBackend(std::string);
	    int InvalidRequest();
	    void CountStart();
	    void CountEnd();
	    void GetTime();
};

std::string backend_handler::ProcessToBackend(std::string packet) {
	if(!call->LoadRequest(packet)) {
		std::cout << "[WARNING] Invalid json pair" << std::endl;
		IsInvalidRequest = 1;
	} else {
		
		// client request process
		if (call->Isset(call->Request("login"))) {
			std::cout << "[NOTE] Login request" << std::endl;
			if(db->LoginWithEmailPassword(call->Request("email"), call->Request("password"))) {
				std::cout << "[NOTE] Login successful" << std::endl;
				// User Login Successful
				return "{\"return\": true, \"message\": \"Login success\"}";
			} else {
				// User login failed and send what is problem
                std::cout << "[NOTE] Login failed" << std::endl;
				return db->TellErrors();
			}
		} else if (call->Isset(call->Request("register"))) {
			std::cout << "[NOTE] Registration request" << std::endl;
			if (db->RegisterWithEmailPassword(call->Request("username"), call->Request("email"), call->Request("password"))) {
				std::cout << "[NOTE] Registration successfull" << std::endl;
				return "{\"return\": true, \"message\": \"Account has been created\"}";
			} else {
				std::cout << "[NOTE] Registration failed" << std::endl;
				return db->TellErrors();
			}
		} else {
		  std::cout << "[WARNING] Unknown Request" << std::endl;
		  IsInvalidRequest = 1;
		}
		
	}
	return "{\"return\": true, \"message\": \"Internal server bug\"}"; 
}

void backend_handler::CountStart(){
	/* Recording the starting clock tick.*/
    start = clock();
}

void backend_handler::CountEnd(){
	// Recording the end clock tick. 
    end = clock(); 
}

void backend_handler::GetTime(){
	// Calculating total time taken by the program. 
    double time_taken = double(end - start) / double(CLOCKS_PER_SEC);
    std::cout << "[NOTE] Process completed in " << std::fixed << time_taken << std::setprecision(5) << " sec" << std::endl;
}

int backend_handler::InvalidRequest() {
	return IsInvalidRequest;
}

#endif