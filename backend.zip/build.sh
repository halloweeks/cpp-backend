#!/usr/bin/env bash
if ! dpkg -s cmake >/dev/null 2>&1; then
  echo "We not found cmake in your system\nPlease run apt-get install cmake"
  exit 1;
fi

rm -rf build
mkdir build
cd build
cmake ..
make
cp server ../
cp client ../
rm -rf ../build