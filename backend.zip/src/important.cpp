while (((row=mysql_fetch_row(results)) !=NULL)) {
   if(row[3] == 1) {
      // account is banned
   } else {
      // account is not banned
   }
}
					