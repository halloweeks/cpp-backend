#include <iostream>
#include <string>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <pthread.h>
#include "backend_handler.hpp"

#define BUFFER_SIZE 4000
#define PORT 8888

// Define connection handler function
void *connection_handler(void *);

int main(int argc , char *argv[]){
    // Print messages
	std::cout << "[INFO] STARTING UP THE SERVER" << std::endl;
	std::cout << "[INFO] SERVER PORT NUMBER 8888" << std::endl;
	std::cout << "[INFO] PROTOCOL TCP" << std::endl;
	std::cout << "[INFO] DATABASE MySQL" << std::endl;
	std::cout << "[INFO] SEND RECEIVE IN JSON FORMAT" << std::endl;
	
	int socket_desc , client_sock, c;
	struct sockaddr_in server , client;
	
	// Create a TCP socket
	socket_desc = socket(AF_INET, SOCK_STREAM, 0);
	// check socket creation
	if (socket_desc==-1) {
		std::cout << "[ERROR] COULD NOT CREATE SOCKET" << std::endl;
		return 1;
	} else {
		std::cout << "[INFO] SOCKET HAS BEEN CREATED" << std::endl;
	}
	
	// Prepare the sockaddr_in structure
	server.sin_family = AF_INET;
	server.sin_addr.s_addr = INADDR_ANY;
	server.sin_port = htons(PORT);
	
	// Bind the address and port
	if (bind(socket_desc,(struct sockaddr *)&server, sizeof(server))<0) {
		perror("[BIND]");
		return -1;
	} else {
		std::cout << "[INFO] BIND DONE" << std::endl;
	}
	
	// Listen on the socket, with 40 max connection requests queued
	if (listen(socket_desc, 3)==0) {
		std::cout << "[INFO] LISTENING" << std::endl;
	}else{
		std::cout << "[ERROR] FAILED TO LISTENING" << std::endl;
		return 1;
	}
	
	//Accept and incoming connection
	std::cout << "[NOTE] WAITING FOR INCOMING CONNECTIONS" << std::endl;
	c = sizeof(struct sockaddr_in);
	pthread_t thread_id;
	
	while ((client_sock = accept(socket_desc, (struct sockaddr *)&client, (socklen_t*)&c))) {
		if (pthread_create(&thread_id, NULL,  connection_handler,(void*)&client_sock)<0) {
			// std::cout << "[ERROR] COULD NOT CREATE THREAD" << std::endl;
			std::cout << "[WARNING] CONNECTION ACCEPTING FAILED" << std::endl;
		} else {
			// Now join the thread , so that we dont terminate before the thread
			//pthread_join( thread_id , NULL);
			std::cout << "[INFO] CONNECTION ACCEPTED CONNECTION ID "<< client_sock << std::endl;
		}
	}
	return 0;
}

// This will handle connection for each client
void *connection_handler(void *socket_desc){
  //Get the socket descriptor
  int sock = *(int*)socket_desc;
  int read_size, write_size;
  char ClientRequest[BUFFER_SIZE];
  std::string ServerResponse;
  
  //Receive a message from client
  while((read_size = recv(sock, ClientRequest, BUFFER_SIZE,0))>0){
      std::cout << "--------------------------" << std::endl;
  	//end of string marker
	  ClientRequest[read_size] = '\0';
	  ServerResponse = callback->ProcessToBackend(ClientRequest);
	  if(send(sock ,ServerResponse.c_str(), strlen(ServerResponse.c_str()), 0) == -1) {
		  std::cout << "[WARNING] CAN'T SEND PACKET TO CONNECTION ID " << sock << std::endl;
	  }
      //clear the message buffer
      memset(ClientRequest, 0, BUFFER_SIZE);
  }
  
  // check received
  if(read_size == 0) {
  	std::cout << "[NOTE] CONNECTION ID " << sock << " DISCONNECTED " << std::endl;
      fflush(stdout);
  } else if(read_size == -1) {
      std::cout << "[WARNING] FAILED TO RECEIVE PACKETS" << std::endl;
  }
  return 0;
}