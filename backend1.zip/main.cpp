#ifndef _SERVER_LOGIC_
#define _SERVER_LOGIC_

class logic {
	private:
	std::string response_message;
	public:
	// Login with email, password
	bool LoginWithEmailPassword(std::string, std::string);
	// Register with username, email, password
	bool RegisterWithEmailPassword(std::string, std::string, std::string);
	// Use true to response in json format else plan text
	std::string Response(bool);
};

bool logic::LoginWithEmailPassword(std::string email, std::string password) {
	bool success = true;
	
}

std::string logic::Response(bool JsonResponseType = false){
	return response_message;
}

#endif