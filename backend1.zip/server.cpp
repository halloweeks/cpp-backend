/*

c++ socket server example, handles multiple clients using threads

Compile gcc server.c -lpthread -o server

*/

// Included headers files
#include<iostream>
#include<string>
#include<sys/socket.h>
#include<arpa/inet.h>
#include<unistd.h>
#include<pthread.h>
#include "include/backend_handler.hpp"
 
//the thread function

void *connection_handler(void *);

int main(int argc , char *argv[]){
	
  std::cout << "[NOTE] Starting up the SERVER" << std::endl;
  std::cout << "[NOTE] SERVER Port Number 8888" << std::endl;
  std::cout << "[NOTE] Protocol TCP" << std::endl;
  std::cout << "[NOTE] Database MySQL" << std::endl;
  std::cout << "[NOTE] Send Receive in JSON Format" << std::endl;
  
  
  int socket_desc , client_sock, c;

  struct sockaddr_in server , client;
  
  // Create a TCP socket
  socket_desc = socket(AF_INET, SOCK_STREAM, 0);
  
  if (socket_desc==-1) {
    std::cout << "[ERROR] Could not create socket" << std::endl;
    return 1;
  }else{
    std::cout << "[NOTE] Socket has been created" << std::endl;
  }
  
  //Prepare the sockaddr_in structure

  server.sin_family = AF_INET;

  server.sin_addr.s_addr = INADDR_ANY;

  server.sin_port = htons(8888);


  // Bind the address and port
  if (bind(socket_desc,(struct sockaddr *)&server, sizeof(server)) < 0) {
    //std::cout << "[ERROR] Unable to bind" << std::endl;
    perror("[ERROR] Binding failed. Socket is being used. Please try again in 15 seconds.");
    return -1;
  } else {
    std::cout << "[NOTE] Bind done" << std::endl;
  }
  
  //Listen on the socket, with 40 max connection requests queued
  if (listen(socket_desc, 3)==0) {
    std::cout << "[NOTE] Listening" << std::endl;
  }else{
    std::cout << "[ERROR] Failed to listening" << std::endl;
    return 1;
  }
  
  //Accept and incoming connection
  std::cout << "[NOTE] Waiting for incoming connections" << std::endl;
  
  c = sizeof(struct sockaddr_in);

	pthread_t thread_id;
	
	
	while ((client_sock = accept(socket_desc, (struct sockaddr *)&client, (socklen_t*)&c)) ) {
	  if (pthread_create(&thread_id, NULL,  connection_handler,(void*)&client_sock) < 0) {
	    //std::cout << "[ERROR] could not create thread" << std::endl;
	    std::cout << "[ERROR] Client connection declined" << std::endl;
	  } else {
	    //Now join the thread , so that we dont terminate before the thread
	    //pthread_join( thread_id , NULL);
        std::cout << "[NOTE] Client connected" << std::endl;
      }
	}
	return 0;
}


/*

 * This will handle connection for each client

 * */

void *connection_handler(void *socket_desc){
  //Get the socket descriptor
  int sock = *(int*)socket_desc;
  
  int read_size, write_size;

  char ClientRequest[2000];
  std::string ServerResponse;
  
  backend_handler *callback = new backend_handler;
  
  //Receive a message from client
  while((read_size = recv(sock, ClientRequest, 2000,0))>0){
  	
  	//end of string marker
	  ClientRequest[read_size] = '\0';
	
	std::cout << "------------------------------------------" << std::endl;
	
	callback->TimerStart();
	
	 ServerResponse = callback->ProcessToBackend(ClientRequest);
	
	if (callback->InvalidRequest()) {
		std::cout << "[NOTE] Security reason for client connection closed" << std::endl;
		close(sock);
	} else {
		if(send(sock ,ServerResponse.c_str(), strlen(ServerResponse.c_str()), 0) == -1) {
			std::cout << "[WARNING] Can't send response to client" << std::endl;
		}
	}
	
	callback->TimerStop();
	
	callback->PrintTime();
	
    //clear the message buffer
	
    memset(ClientRequest, 0, 2000);
    
  }
  
  if (!callback->InvalidRequest()) {
  	if(read_size == 0) {
  	    std::cout << "[NOTE] Client disconnected" << std::endl;
         fflush(stdout);
      } else if(read_size == -1) {
      	std::cout << "[WARNING] " << "Failed to receive client packets" << std::endl;
      }
   }
   
  return 0;
  
}