#include <iostream>
#include <nlohmann/json.hpp>
#include <mariadb/mysql.h>
#include <string>

using json = nlohmann::json;

int main(){
	MYSQL *connect = mysql_init(NULL);
	MYSQL_RES *res;
	MYSQL_ROW row;
	json data;
	
	if (!connect) {
		std::cout << "MySQL Initialization" << std::endl;
		return -1;
	}
	
	connect = mysql_real_connect(connect, "localhost", "root", "1234", NULL, 0, NULL, 0);
	
	if (!connect) {
		std::cout << "Can't connect MySQL server" << std::endl;
		return -1;
	}
	
	
	std::string sql = "SELECT * FROM server.users WHERE email='example@gmail.com'";
	//std::string sqli = "SHOW columns FROM server.users";
	
	mysql_query(connect, sql.c_str());
	res = mysql_store_result(connect);
	
	if (mysql_num_rows(res) > 0 ) {
		row=mysql_fetch_row(res);
		
		data[0]["user_id"] = row[0];
		data[0]["username"] = row[1];
		data[0]["email"] = row[2];
	    data[0]["password"] = row[3];
	    std::cout << data.dump(4, ' ', true, nlohmann::detail::error_handler_t::strict) << std::endl;
	
	} else {
		std::cout << "No results found our database" << std::endl;
	}
	
	mysql_close(connect);
	
	return 0;
}