#ifndef _DATABASE_
#define _DATABASE_

#include <iostream>
#include <mariadb/mysql.h>

class mariadb {
	private:
	MYSQL *connect;
	MYSQL_RES *res;
	MYSQL_ROW row;
	int ErrorCount = 0;
	std::string ErrorMessage;
	std::string AuthenticationToken;
	
	public:
	int mysqli_open();
	int mysqli_close();
	std::string TellErrors();
	int LoginWithEmailPassword(std::string, std::string);
	std::string GetAuthToken();
	
};

int mariadb::mysqli_open(){
  connect = mysql_init(NULL);
  if (!connect) {
  	ErrorMessage = "{\"return\": false, \"message\": \"Server currently busy\"}";
    std::cout << "[WARNING] MySQL Initialization" << std::endl;
    return false;
  }
	connect = mysql_real_connect(connect, "localhost", "root", "1234", NULL, 0, NULL, 0);
	if (!connect) {
		ErrorMessage = "{\"return\": false, \"message\": \"Server currently busy\"}";
		std::cout << "[WARNING] Can't connect MySQL server" << std::endl;
		return false;
	}
	return true;
}

int mariadb::mysqli_close(){
	if (connect) {
		mysql_close(connect);
		return true;
	}
	return false;
}

std::string mariadb::TellErrors() {
  return ErrorMessage;
}

// Login Email and Password System
int mariadb::LoginWithEmailPassword(std::string email, std::string password) {
	// state is default success
	int state = 1;
	// select query string
	std::string sql = "SELECT * FROM server.users WHERE email='"+email+"'";
	// Open MySQL connection
	if(!mariadb::mysqli_open()) {
		// if not open MySQL connection
		state = 0;
	} else {
		// MySQL execute query
		if(mysql_query(connect, sql.c_str())) {
			// if query failed to print message in the server
			std::cout << "Failed: " << mysql_error(connect) << std::endl;
			// state is not return success set 0 means return login failed
			state = 0;
		}
		// Store MySQL query result
		res = mysql_store_result(connect);
		
		if (mysql_num_rows(res) == 1) {
			std::cout << "[NOTE] Account found" << std::endl;
			
			while (((row=mysql_fetch_row(res)) !=NULL)) {
				if(!password.compare(row[4])) {
					AuthenticationToken = std::string("{\"return\": true, \"message\": \"login success\", \"auth_token\": \"") + row[5] + std::string("\"}");

					std::cout << "[NOTE] Password matched" << std::endl;
					state = 1;
				} else {
					std::cout << "[NOTE] Password doesn't match" << std::endl;
					ErrorMessage = "{\"return\": false, \"message\": \"Password incorrect\"}";
				}
			}
			
		} else {
			ErrorMessage = "{\"return\": false, \"message\": \"This email doesn't exist in our database\"}";
			state = 0;
			std::cout << "[NOTE] Account not found" << std::endl;
		}
		mariadb::mysqli_close();
	}
	return state;
}

std::string mariadb::GetAuthToken() {
	return AuthenticationToken;
}

#endif