#ifndef _COLOR_
#define _COLOR_


std::string textcolor(std::string text = "Hello World!", int color = 1) {
	if (color == 1 ) {
		return std::string("\e[1;31m") + text + std::string("\e[0m");
	} else if (color == 2) {
		return std::string("\e[1;32m") + text + std::string("\e[0m");
	} else if (color == 3) {
		return std::string("\e[1;33m") + text + std::string("\e[0m");
	} else if (color == 4) {
		return std::string("\e[1;34m") + text + std::string("\e[0m");
	} else if (color == 5) {
		return std::string("\e[1;35m") + text + std::string("\e[0m");
	} else if (color == 6) {
		return std::string("\e[1;36m") + text + std::string("\e[0m");
	}
	return text;
}

#endif