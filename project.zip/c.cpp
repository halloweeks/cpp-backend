// Client side C/C++ program to demonstrate Socket programming
#include <iostream>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <string>

#define ADDRESS "127.0.0.1"
#define PORT 8888
#define BUFFER_SIZE 2000

int main(int argc, char const *argv[]){
	clock_t start, end;
	int sock = 0, valread;
	struct sockaddr_in serv_addr;
    char buffer[BUFFER_SIZE] = {0};
  
  // socket create and varification
  if ((sock = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
    std::cout << "[ERROR] " << "Socket creating failure" << std::endl;
  } else {
      std::cout << "[NOTE] " << "Socket created" << std::endl;
  }
  
  // assign IP, PORT
  serv_addr.sin_family = AF_INET;
  serv_addr.sin_port = htons(PORT);
  
  // Convert IPv4 and IPv6 addresses from text to binary form
  
  if(inet_pton(AF_INET, ADDRESS, &serv_addr.sin_addr)<=0){
    std::cout << "[ERROR] " << "Invalid address/ Address not supported" << std::endl;
  } else {
  	std::cout << "[NOTE] " << "Address is supported" << std::endl;
  }
  
  // connect the client socket to server socket
  if(connect(sock, (struct sockaddr *)&serv_addr, sizeof(serv_addr)) < 0){
    std::cout << "[ERROR] " << "Unable to connect the server" << std::endl;
  } else {
      std::cout << "[NOTE] " << "We are connected to the server" << std::endl;
  }
  
  std::cout << "(1) Enter 1 for login\n(2) Enter 2 for register\n(3) Enter 3 for exit" << std::endl;
    
    int input_code;
       std::string username;
       std::string email;
       std::string password;
       std::string request_data;
       std::string request_type;
    
   while(true) {
       
       std::cout << "\n[tcp]> ";
       std::cin >> input_code;
       std::cout << std::endl;
       
       if (input_code == 1) {
       	std::cout << "Enter email address" << std::endl;
           getline(std::cin, email);
           std::cout << "Enter Password" << std::endl;
       	getline(std::cin, password);
       
           if (! email.compare("")) {
           	std::cout << "Email is blank" << std::endl;
           } else if (!password.compare("")) {
           	std::cout << "Password is blank" << std::endl;
           } else {
           	request_type = "Login request send to server";
           	request_data = std::string("{\"login\": \"login\", \"email\": \"") + email + std::string("\", \"password\": \"") + password + std::string("\"}");
           }
       } else if (input_code == 2) {
       	std::cout << "Enter username" << std::endl;
           getline(std::cin, username);
           std::cout << "Enter email address" << std::endl;
           getline(std::cin, email);
           std::cout << "Enter Password" << std::endl;
           getline(std::cin, password);
           
           if (!username.compare("")) {
           	std::cout << "Username empty" << std::endl;
           } else if (!email.compare("")) {
           	std::cout << "Email empty" << std::endl;
           } else if (!password.compare("")) {
           	std::cout << "Password empty" << std::endl;
           } else {
           	request_type = "Registration request send to server";
           	request_data = std::string("{\"register\": \"register\", \"username\": \"") + username + std::string("\", \"email\": \"") + email + std::string("\", \"password\": \"") + password + std::string("\"}");         
           }
       
       } else if (input_code == 3) {
       	std::cout << "Bye!" << std::endl;
       	break;
       } else {
       	std::cout << "Invalid option select" << std::endl;
       }
       
       if (request_data.compare("")) {
       	if (send(sock, request_data.c_str(), strlen(request_data.c_str()), 0)) {
       	    std::cout << "[REQUEST] " << request_type << std::endl;
           } else {
           	std::cout << "[REQUEST][ERROR] " << "Failed to send" << std::endl;
          }
          
          if(recv(sock, buffer, strlen(buffer), 0)>0){
          	std::cout << "[RESPONSE] " << buffer << std::endl;
              memset(buffer, 0, 2000);
          } else {
          	std::cout << "[RESPONSE][ERROR] " << "Can't read response" << std::endl;
          }
      }
  }
  
  close(sock);
  
  return 0; 
}