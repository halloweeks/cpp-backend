// Client side C/C++ program to demonstrate Socket programming
#include <iostream>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <string>
#include <nlohmann/json.hpp>

using json = nlohmann::json;

#define ADDRESS "127.0.0.1"
#define PORT 8888
#define BUFFER_SIZE 2000

int main(int argc, char const *argv[]){
	json data;
	clock_t start, end;
	int sock = 0, valread;
	struct sockaddr_in serv_addr;
    char buffer[BUFFER_SIZE] = {0};
  
  // socket create and varification
  if ((sock = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
    std::cout << "[ERROR] SOCKET CREATING FAILED" << std::endl;
    return -1;
  } else {
      std::cout << "[NOTE] SOCKET HAS BEEN CREATED" << std::endl;
  }
  
  // assign IP, PORT
  serv_addr.sin_family = AF_INET;
  serv_addr.sin_port = htons(PORT);
  
  // Convert IPv4 and IPv6 addresses from text to binary form
  
  if(inet_pton(AF_INET, ADDRESS, &serv_addr.sin_addr)<=0){
    std::cout << "[ERROR] INVALID ADDRESS/ ADDRESS NOT SUPPORTED" << std::endl;
    return -1;
  } else {
  	std::cout << "[NOTE] ADDRESS IS SUPPORTED" << std::endl;
  }
  
  // connect the client socket to server socket
  if(connect(sock, (struct sockaddr *)&serv_addr, sizeof(serv_addr)) < 0){
    std::cout << "[ERROR] UNABLE TO CONNECT THE SERVER" << std::endl;
    return -1;
  } else {
      std::cout << "[INFO] SERVER CONNECTED" << std::endl;
  }
  
  std::cout << "\n(1) ENTER 1 FOR LOGIN\n(2) ENTER 2 FOR REGISTER\n(3) ENTER 3 FOR EXIT" << std::endl;
   
   while(true) {
   	std::string code, username, email, password, request_data, request_type;
       std::cout << "\n[TCP]> ";
       getline(std::cin, code);
       std::cout << std::endl;
       
       if (!code.compare("1")) {
       	std::cout << "LOGIN YOUR ACCOUNT\n\nENTER EMAIL ADDRESS > ";
           getline(std::cin, email);
           
           if (!email.compare("")) {
           	std::cout << "EMAIL EMPTY" << std::endl;
           } else {
           	request_data = std::string("{\"login\": \"login\", \"email\": \"") + email + std::string("\", \"password\": \"") + password + std::string("\"}");
               request_type = "LOGIN REQUEST SEND";
           }
           
       } else if (!code.compare("2")) {
       	std::cout << "CREATE A NEW ACCOUNT\n\nENTER USERNAME > ";
           getline(std::cin, username);
           std::cout << "ENTER EMAIL ADDRESS > ";
           getline(std::cin, email);
           
           if (!username.compare("")) {
           	std::cout << "USERNAME EMPTY" << std::endl;
           } else if (!email.compare("")) {
           	std::cout << "EMAIL EMPTY" << std::endl;
           } else {
           	request_data = std::string("{\"register\": \"register\", \"username\": \"") + username + std::string("\", \"email\": \"") + email + std::string("\", \"password\": \"") + password + std::string("\"}");
               request_type = "REGISTRATION REQUEST SEND";
           }
       } else if (!code.compare("3")) {
       	std::cout << "BYE!" << std::endl;
       	break;
       } else {
       	std::cout << "INVALID OPTION SELECT" << std::endl;
           std::cout << "(1) ENTER 1 FOR LOGIN\n(2) ENTER 2 FOR REGISTER\n(3) ENTER 3 FOR EXIT" << std::endl;
       }
       
       if (request_data.compare("")) {
       	if (send(sock, request_data.c_str(), strlen(request_data.c_str()), 0)) {
       	    std::cout << "\n[REQUEST] " << request_type << std::endl;
           } else {
           	std::cout << "[ERROR] " << "FAILED TO SEND" << std::endl;
          }
          
          if(recv(sock, buffer, BUFFER_SIZE, 0)>0){
            if (json::accept(buffer)) {
            	data = json::parse(buffer);
                std::cout << "[RESPONSE] " << data.value("message", "") << std::endl;
            } else {
	        	std::cout << "[RESPONSE] " << buffer << std::endl;
            }
              memset(buffer, 0, BUFFER_SIZE);
          } else {
          	std::cout << "[ERROR] " << "CAN'T READ RESPONSE" << std::endl;
          }
      }
  }
  
  close(sock);
  
  return 0; 
}