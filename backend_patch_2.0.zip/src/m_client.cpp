#include "socket.hpp"

int main(){
   // Store receive response from server
   std::string buffer, msg;
   // Connect the server
   if (sock->Connect("0.0.0.0", 8888)) {
      std::cout << "connection success" << std::endl;
   } else {
      std::cout << sock->Error() << std::endl;
   }
   
   while (true) {
      std::cout << "[TCP]> ";
      getline(std::cin, msg);
      if (!msg.compare("")) {
         msg = "default message";
      } else if (!msg.compare("exit")) {
         std::cout << "Bye!" << std::endl;
         break;
      }
      
      // send message to connected server
      if (sock->Send(msg)) {
         std::cout << "Send: " << msg << std::endl;
      } else {
         std::cout << "Unable to send" << std::endl;
      }
      
      // receive message from connected server
      if (sock->Receive(buffer) > 0) {
         std::cout << "Receive: " << buffer << std::endl;
      } else {
         std::cout << "Unable to receive" << std::endl;
      }
     
   }
   
   // Close the connection
   sock->Close();
   return 0;
}