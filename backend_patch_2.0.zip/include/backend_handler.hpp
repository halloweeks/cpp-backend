#ifndef BACKEND_PROCESS_HPP
#define BACKEND_PROCESS_HPP

#include <iostream>
#include "logic.hpp"
#include "request_handler.hpp"
#include <iomanip>
#include <time.h>

class backend_handler {
    public:
    std::string ProcessToBackend(std::string);
};

// Main backend function return request response
std::string backend_handler::ProcessToBackend(std::string packet) {
    // we are checking request format is correct json parse
	if(!client->LoadRequest(packet)) {
		std::cout << "[WARNING] INVALID JSON PARSE" << std::endl;
		return "{\"return\": true, \"message\": \"Invalid json parse\"}"; 
	} else {
		// check condition if user request login
		if (client->Isset(client->Request("login"))) {
			std::cout << "[INFO] LOGIN REQUEST" << std::endl;
			if(db->LoginWithPlayGames(client->Request("email"))) {
				std::cout << "[INFO] LOGIN SUCCESSFUL" << std::endl;
				return db->Response();
			} else {
                std::cout << "[INFO] LOGIN UNSUCCESSFUL" << std::endl;
				return db->Response();
			}
			// if user request registration
		} else if (client->Isset(client->Request("register"))) {
			std::cout << "[INFO] REGISTRATION REQUEST" << std::endl;
			if (db->RegisterWithPlayGames(client->Request("username"), client->Request("email"))) {
				std::cout << "[INFO] REGISTRATION SUCCESSFUL" << std::endl;
				return db->Response();
			} else {
				std::cout << "[INFO] REGISTRATION UNSUCCESSFUL" << std::endl;
				return db->Response();
			}
		} else {
			// Not match any request
			std::cout << "[WARNING] UNKNOWN REQUEST" << std::endl;
		}
		
	}
	
}

backend_handler *callback = new backend_handler;

#endif