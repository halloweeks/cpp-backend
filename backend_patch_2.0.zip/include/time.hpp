#ifndef EXECUTION_counter
#define EXECUTION_counter

#include <iostream>
#include <time.h>

class counter {
   private:
   clock_t start, end;
   public:
   void TimeStart();
   void TimeStop();
   void TimeShow(std::string);
};

void counter::TimeStart() {
   /* Recording the starting clock tick.*/
   start = clock();
}

void counter::TimeStop() {
   // Recording the end clock tick. 
   end = clock();
}

void counter::TimeShow(std::string text) {
   // Calculating total time taken by the program. 
   double time_taken = double(end - start) / double(CLOCKS_PER_SEC); 
   std::cout << text << std::fixed << time_taken << std::setprecision(5) << " sec" << std::endl;
}

counter *count = new counter;
#endif